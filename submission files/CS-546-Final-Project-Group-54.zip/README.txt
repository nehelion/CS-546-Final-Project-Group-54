- Group 54

After extracting codebase
To run application Simply Run inside codebase:

> npm start

db_dump contins our used db 

The application will start on:

> http://localhost:3000

And the database is set to:

> "serverUrl": "mongodb://localhost:27017/"
> "database": "Film_Foray"